package ru.touchin.extensions.rx.utils

object StringConstants {
    const val OPTIONAL_UNWRAPPING_ERROR_MESSAGE = "Wrapped object must not be null"
}
