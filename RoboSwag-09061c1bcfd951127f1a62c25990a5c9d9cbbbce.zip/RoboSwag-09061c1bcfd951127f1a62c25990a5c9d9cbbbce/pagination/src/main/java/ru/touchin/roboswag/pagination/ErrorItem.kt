package ru.touchin.roboswag.pagination

object ErrorItem
