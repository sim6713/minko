package ru.touchin.lifecycle.viewmodel

object LifecycleViewModelProviders : BaseLifecycleViewModelProviders()
