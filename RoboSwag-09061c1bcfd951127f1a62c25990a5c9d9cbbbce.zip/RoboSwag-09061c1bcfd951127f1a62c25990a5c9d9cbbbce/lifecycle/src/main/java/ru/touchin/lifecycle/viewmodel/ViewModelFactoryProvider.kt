package ru.touchin.lifecycle.viewmodel

interface ViewModelFactoryProvider {

    val viewModelFactory: ViewModelFactory

}
