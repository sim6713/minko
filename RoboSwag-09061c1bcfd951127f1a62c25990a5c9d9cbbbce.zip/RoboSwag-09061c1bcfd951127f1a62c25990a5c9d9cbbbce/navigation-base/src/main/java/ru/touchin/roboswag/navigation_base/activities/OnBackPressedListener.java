package ru.touchin.roboswag.navigation_base.activities;

public interface OnBackPressedListener {

    boolean onBackPressed();

}
