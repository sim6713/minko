package ru.touchin.roboswag.navigation_base.scopes

import javax.inject.Scope

@Scope
annotation class FragmentScope
