package ru.touchin.roboswag.navigation_cicerone.flow

import javax.inject.Qualifier

@Qualifier
annotation class FlowNavigation
