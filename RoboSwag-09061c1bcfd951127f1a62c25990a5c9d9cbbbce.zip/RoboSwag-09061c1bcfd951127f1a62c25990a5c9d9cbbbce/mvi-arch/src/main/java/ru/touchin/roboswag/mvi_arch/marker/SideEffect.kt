package ru.touchin.roboswag.mvi_arch.marker

interface SideEffect
