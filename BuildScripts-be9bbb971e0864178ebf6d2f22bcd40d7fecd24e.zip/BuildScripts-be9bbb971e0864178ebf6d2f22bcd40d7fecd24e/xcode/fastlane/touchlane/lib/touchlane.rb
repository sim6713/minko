module Touchlane
  require_relative "configuration_type"
  require_relative "configuration"
end