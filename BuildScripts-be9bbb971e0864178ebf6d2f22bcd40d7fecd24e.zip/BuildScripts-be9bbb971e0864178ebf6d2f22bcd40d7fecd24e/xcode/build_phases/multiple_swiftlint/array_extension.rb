class Array
    def nilOrEmpty?
        self.nil? or self.empty?
    end
end
