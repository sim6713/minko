package static_analysis.plugins

open class StaticAnalysisExtension(
        var excludes: String = "",
        var buildScriptDir: String? = null
)
