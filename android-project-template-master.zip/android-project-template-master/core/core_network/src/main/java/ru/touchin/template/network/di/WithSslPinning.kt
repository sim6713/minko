package ru.touchin.template.network.di

import javax.inject.Qualifier

@Qualifier
annotation class WithSslPinning
