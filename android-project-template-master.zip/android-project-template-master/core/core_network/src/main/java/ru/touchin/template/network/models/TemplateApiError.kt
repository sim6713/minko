package ru.touchin.template.network.models

enum class TemplateApiError {

    INVALID_PARAMETERS,

    VALID_RESPONSE

}
