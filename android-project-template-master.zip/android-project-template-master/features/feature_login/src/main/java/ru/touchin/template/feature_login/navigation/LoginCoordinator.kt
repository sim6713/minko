package ru.touchin.template.feature_login.navigation

import ru.touchin.roboswag.navigation_base.scopes.FragmentScope

@FragmentScope
interface LoginCoordinator {
    fun openMainScreen()
}
